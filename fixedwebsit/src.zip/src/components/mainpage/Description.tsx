

export default function Description() {
    return (
      <p className="description">
        I'm <strong>Sid Meka</strong> and this is my website
      </p>
    );
  }
  