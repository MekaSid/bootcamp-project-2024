
export default function Heading() {
    return <h1 className="heading">Hi!</h1>;
  }
  